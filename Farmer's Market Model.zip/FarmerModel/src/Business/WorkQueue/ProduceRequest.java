
package Business.WorkQueue;

/**
 *
 * @author Ajay Mohandas
 */
public class ProduceRequest extends WorkRequest{
    
    private String testResult;

    public String getTestResult() {
        return testResult;
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
    }
    
    
}
