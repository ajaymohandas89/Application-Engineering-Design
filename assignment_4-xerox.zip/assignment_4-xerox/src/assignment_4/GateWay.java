/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_4;

import assignment_4.analytics.*;
import assignment_4.entities.*;
import java.io.IOException;
import java.util.Map;

/**
 *
 * @author Ajay,Gurjot,Harsh
 */
public class GateWay {

    DataReader orderReader;
    DataReader productReader;
    AnalysisHelper helper;

    public GateWay() throws IOException {
        DataGenerator generator = DataGenerator.getInstance();
        orderReader = new DataReader(generator.getOrderFilePath());
        productReader = new DataReader(generator.getProductCataloguePath());
        helper = new AnalysisHelper();
    }

    public static void main(String args[]) throws IOException {
        GateWay gateway = new GateWay();
        gateway.readData();
    }

    private void readData() throws IOException {
        String[] row;
        while ((row = productReader.getNextRow()) != null) {
            generateProduct(row);
        }
        while ((row = orderReader.getNextRow()) != null) {
            generateOrder(row);
        }
        runAnalysis();
    }

    private void generateProduct(String[] row) {
        int productId = Integer.parseInt(row[0]);
        int minPrice = Integer.parseInt(row[1]);
        int maxPrice = Integer.parseInt(row[2]);
        int targetPrice = Integer.parseInt(row[3]);
        Product p = new Product(productId, minPrice, maxPrice, targetPrice);
        DataStore.getInstance().getProduct().put(productId, p);

    }

    private void generateOrder(String[] row) {
        Item i = generateItem(row);
        
        int orderId = Integer.parseInt(row[0]);
        int salesId = Integer.parseInt(row[4]);
        int customerId = Integer.parseInt(row[5]);
        int salesPrice = Integer.parseInt(row[6]);
        int quantity = Integer.parseInt(row[3]);
        
        Order o = new Order(orderId, salesId, customerId, i);
        DataStore.getInstance().getOrder().put(orderId, o);
    }

    private void generateCustomer(String[] row) {
        int customerId = Integer.parseInt(row[5]);
        
        Customer c = new Customer(customerId);
        DataStore.getInstance().getCustomer().put(customerId, c);

    }

    private Item generateItem(String[] row) {

        int itemId = Integer.parseInt(row[1]);
        int salesPrice = Integer.parseInt(row[6]);
        int quantity = Integer.parseInt(row[3]);
        int productId = Integer.parseInt(row[2]);

        Item i = new Item(itemId, salesPrice, quantity, productId);
        DataStore.getInstance().getItem().put(itemId, i);
        return i;
    }

    private void generateSalesPerson(String[] row) {
        int salesId = Integer.parseInt(row[4]);
        
        SalesPerson sp = new SalesPerson(salesId);
        DataStore.getInstance().getSalesPerson().put(salesId, sp);
    }

    private void runAnalysis() {
        helper.topProducts();
        helper.topCustomers();
        helper.topSalesPerson();
        helper.totalRevenue();

    }
}
