/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_4.entities;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ajay,Gurjot,Harsh
 */
public class Customer {
   int customerId;
    private List<Order> orders;
   
   public Customer(int customerId){
       this.customerId = customerId;
       this.orders = new ArrayList<>();
   }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    } 
    
   
}
